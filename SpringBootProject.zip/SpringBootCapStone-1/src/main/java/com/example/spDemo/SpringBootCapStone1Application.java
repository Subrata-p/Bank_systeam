package com.example.spDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;





@SpringBootApplication

public class SpringBootCapStone1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCapStone1Application.class, args);
	}
	
}
