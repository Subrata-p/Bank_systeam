package com.example.spDemo.exception;

public class ResourceNotFound extends Exception{

	private static final long serialVersionUID = 1L;
	public ResourceNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResourceNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
