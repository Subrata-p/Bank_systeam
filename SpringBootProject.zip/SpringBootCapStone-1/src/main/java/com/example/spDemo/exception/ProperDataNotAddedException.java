package com.example.spDemo.exception;

public class ProperDataNotAddedException extends Exception{

	public ProperDataNotAddedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
