package com.example.spDemo.exception;

public class AccountDoesNotExist extends Exception{

	public AccountDoesNotExist(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
