package com.example.spDemo.exception;

public class AccountNotFoundException extends Exception{

	public AccountNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
