package com.example.spDemo.exception;

public class CustomerDoesNotExist1 extends Exception{

	public CustomerDoesNotExist1(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
