package com.example.spDemo.exception;

public class AmountInsufficientException extends Exception{

	public AmountInsufficientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
