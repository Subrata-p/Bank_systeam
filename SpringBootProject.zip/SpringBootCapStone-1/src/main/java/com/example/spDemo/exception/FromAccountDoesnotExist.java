package com.example.spDemo.exception;

public class FromAccountDoesnotExist extends Exception{
	private static final long serialVersionUID = 1L;

	public FromAccountDoesnotExist(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
