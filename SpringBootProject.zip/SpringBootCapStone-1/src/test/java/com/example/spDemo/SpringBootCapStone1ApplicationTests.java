package com.example.spDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCapStone1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
