package com.example.spDemo.exception;

public class ToAccountDoesnotExist extends Exception{

	public ToAccountDoesnotExist(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
